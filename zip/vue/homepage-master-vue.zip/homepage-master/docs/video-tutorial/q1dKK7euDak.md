---
layout: Video
title: Cara Mengakses REST API dengan menggunakan Vue.js dan Axios
youtube: q1dKK7euDak
---
