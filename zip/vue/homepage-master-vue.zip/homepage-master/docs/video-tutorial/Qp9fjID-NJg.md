---
layout: Video
title: Edit data di component langsung dari Vue Developer Tools
youtube: Qp9fjID-NJg
---
