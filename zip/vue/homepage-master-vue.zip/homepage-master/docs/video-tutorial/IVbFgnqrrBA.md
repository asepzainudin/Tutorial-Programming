---
layout: Video
title: Menggunakan ES6 Class di Vue.js
youtube: IVbFgnqrrBA
---
