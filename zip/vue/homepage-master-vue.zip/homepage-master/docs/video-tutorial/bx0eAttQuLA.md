---
layout: Video
title: Membuat Otentikasi dengan Laravel dan Vue.js (part 1)
youtube: bx0eAttQuLA
---
