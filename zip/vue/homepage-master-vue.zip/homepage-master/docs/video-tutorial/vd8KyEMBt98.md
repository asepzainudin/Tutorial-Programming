---
layout: Video
title: Membuat Todo List App dengan Vue.js dan Node.js
youtube: vd8KyEMBt98
---
