# Belajar jQuery

ini adalah kumpulan hasil belajar jQuery dari channel youtube JuniorDev

## Tutorial Step by Step Belajar jQuery
Ikuti di [Playlist Seri Video Tutorialnya](https://www.youtube.com/playlist?list=PLFLsT6z_5FzlWJ06-ya24wxjxTsc5Ya1c) di **YouTube**

## Subscribe Channel JuniorDev

[Junior Dev](https://www.youtube.com/c/juniordevindonesia) adalah sebuah channel tutorial komputer dan programmer mulai dari *HTML, CSS, PHP, SQL, Angular, Web Design* dan sebagainya. Di channel ini kamu bisa dapatkan tutorial gratis yang selalu update. Subscribe dan Like channel ini agar kamu bisa mengikuti terus tutorial-tutorialnya.

Jangan lupa follow untuk kontak, bertanya dan berdiskusi
* [Channel Youtube](https://www.youtube.com/c/juniordevindonesia)
* [Like Fanpage](https://www.facebook.com/juniordevindonesiaofficial/)
* [Twitter](http://twitter.com/hello_juniordev)
* [Instagram](https://www.instagram.com/juniordevindonesia/)
* [Google Plus](https://plus.google.com/+JuniorDevIndonesia/posts)
* [Email](mailto:hellojuniordev@gmail.com)

Jangan lupa [**SUBSCRIBE**](https://www.youtube.com/c/juniordevindonesia?sub_confirmation=1) ya..!

## Author
* **Sofyan Setiawan** - *Freelance Web Designer and Developer* - [Facebook](https://www.facebook.com/sofyansetiawanprofile) - [@sofyansetiawann](https://twitter.com/sofyansetiawann)
